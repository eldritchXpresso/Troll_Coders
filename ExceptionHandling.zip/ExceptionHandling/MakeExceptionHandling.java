import java.util.InputMismatchException;
import java.util.Scanner;

public class MakeExceptionHandling {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double number = 0;
        boolean validInput = false;

        while (!validInput) {
            try {
                System.out.print("Enter a Double: ");
		if (scanner.hasNextInt()) {
			throw new InputMismatchException();
		}
		number = scanner.nextDouble();
                validInput = true;
            } catch (InputMismatchException e) {
                System.out.println("That's not a Double. Try again.");
                System.exit(0);
            }
        }

        System.out.println("You entered: " + number);
    }
}
