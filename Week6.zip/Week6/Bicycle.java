class Bicycle extends Vehicle {
	void start () {
		System.out.println("Bike pushes off");
	}
	void honk () {
		System.out.println("Bell Rings");
	}
}
