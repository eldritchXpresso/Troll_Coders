class Bird extends Animal {
	void sound() {
		System.out.println("Bird chirps");
	}
}
