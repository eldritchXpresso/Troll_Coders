class Car extends Vehicle {
	void start() {
		System.out.println("Car ignition turns on");
	}
	void honk() {
		System.out.println("Car honks");
	}
}
