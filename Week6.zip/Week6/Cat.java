class Cat extends Animal {
	void sound() {
		System.out.println("Cat meows");
	}
}
