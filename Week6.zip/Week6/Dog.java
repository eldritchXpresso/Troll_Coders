class Dog extends Animal {
	void sound() {
		System.out.println("Dog barks");
	}
}
