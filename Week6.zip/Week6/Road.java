public class Road {
	public static void main(String[] args) {
		Vehicle v = new Car();
		v.start();
		v.honk();
		Vehicle b = new Bicycle();
		b.start();
		b.honk();
	}
}
