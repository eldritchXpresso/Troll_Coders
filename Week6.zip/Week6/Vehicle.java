class Vehicle {
	void start () {
		System.out.println("Vehicle Starts");
	}
	void honk () {
		System.out.println("Vehicle Honks");
	}
}
