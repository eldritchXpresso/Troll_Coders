public class MathLibrary {
	public static double absoluteValue(double x) {
		if (Double.isNaN(x) || Double.isInfinite(x)) {
        		throw new IllegalArgumentException("Invalid input: " + x);
    		}
		if(x < 0){
			x = x * -1;
		}
		return x;
	}
	public static double powerOfTwo(int n) {
		int ans = 1;
		if (n>=0) {
			double result = 1.0;
			for (int i = 0; i < n; i++) {
			    ans *= 2;
			}	
		}
		else {
			throw new IllegalArgumentException();
		}
		return ans;
	}
	public static double roundToNearestInteger(double x) {
    		if (Double.isNaN(x) || Double.isInfinite(x)) {
        		throw new IllegalArgumentException();
    		}
    		return x >= 0 ? (int)(x + 0.5) : (int)(x - 0.5);
	}
	public static double truncate(double x) {
    		if (Double.isNaN(x) || Double.isInfinite(x)) {
        		throw new IllegalArgumentException("Invalid input: " + x);
    		}
    		return (int)x;
	}
}
