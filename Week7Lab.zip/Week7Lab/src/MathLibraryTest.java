import org.junit.Test;
import static org.junit.Assert.*;
public class MathLibraryTest {
	private static final double DELTA = 0.0001;
	@Test
	public void testPositiveValue() {
		assertEquals(5.0, MathLibrary.absoluteValue(5.0), DELTA);
	}
	@Test
	public void testNegativeValue() {
		assertEquals(10.0, MathLibrary.absoluteValue(-10.0), DELTA);
	}
	@Test
	public void testPowerZero() {
		assertEquals(1, MathLibrary.powerOfTwo(0), DELTA);
	}
	@Test
	public void testPowerOne() {
		assertEquals(2, MathLibrary.powerOfTwo(1), DELTA);
	}
	@Test(expected = IllegalArgumentException.class)public void testNegativePowerOfTwo() {
		MathLibrary.powerOfTwo(-3);
	}
	@Test
	public void testRoundPositive() { 
		assertEquals(2.0, MathLibrary.roundToNearestInteger(2.3), DELTA);
	}
	@Test
	public void testRoundHalfUp() { assertEquals(3.0, MathLibrary.roundToNearestInteger(2.5), DELTA); 
	}
	@Test
	public void testRoundNegative() { assertEquals(-2.0, MathLibrary.roundToNearestInteger(-2.3), DELTA);
	}
	@Test
	public void testRoundNegativeHalf() { assertEquals(-3.0, MathLibrary.roundToNearestInteger(-2.5), DELTA);
	}
	@Test
	public void testTruncatePositive() {
    		assertEquals(4.0, MathLibrary.truncate(4.99), DELTA);
	}
	@Test
	(expected = IllegalArgumentException.class)public void testAbsoluteValueDefensive() {
    		MathLibrary.absoluteValue(Double.NaN);
	}

	@Test
	(expected = IllegalArgumentException.class)public void testRoundDefensive() {
    		MathLibrary.roundToNearestInteger(Double.NaN);
	}
	@Test
	(expected = IllegalArgumentException.class)public void testTruncateInvalidInput() {
    		MathLibrary.truncate(Double.NaN);
	}
	@Test
	(expected = IllegalArgumentException.class)public void testAllFunctionsRejectInfinity() {
    		MathLibrary.absoluteValue(Double.POSITIVE_INFINITY);
    		MathLibrary.roundToNearestInteger(Double.POSITIVE_INFINITY);
    		MathLibrary.truncate(Double.POSITIVE_INFINITY);
    		MathLibrary.powerOfTwo((int)Double.POSITIVE_INFINITY);
	}
	
}
